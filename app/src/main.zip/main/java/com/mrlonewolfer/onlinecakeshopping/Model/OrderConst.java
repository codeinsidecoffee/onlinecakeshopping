package com.mrlonewolfer.onlinecakeshopping.Model;

public interface OrderConst {

    String ORDER_DATE="order_date";
    String ORDER_ID="order_id";

    String ORDER_AMOUNT="order_amount";
    String TOTAL_PRODUCT="total_product";
    String USER_ID="user_id";
    String PRODUCT_ID="product_id";
    String TOTAL_UNIT="total_unit";
    String UNIT_RATE="unit_rate";
    String PURCHASE_AMOUNT="purchase_amount";
    String CID="cid";
    String PRODUCT_QTY_TYPE="product_qty_type";
    String PRODUCT_QTY_ID="product_qty_id";
    String PRODUCT_STATUS="product_status";

    String ORDER_DETAILS_ID="order_details_id";
    String RECEIVE_DATE="receive_date";
    String RECEIVE_TIME="receive_time";
    String ORDER_STATUS="order_status";

    String SEND_ORDER_LIST="send_order_list";






}
