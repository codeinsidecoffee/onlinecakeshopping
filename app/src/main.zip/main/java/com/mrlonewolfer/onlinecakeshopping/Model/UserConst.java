package com.mrlonewolfer.onlinecakeshopping.Model;

public interface UserConst {

    String Flag="flag";
    String ID="id";
    String FIRST_NAME="fname";
    String LAST_NAME="lname";
    String MOBILE="mobile";
    String EMAIL="email";
    String Pass="pass";
    String ADDRESS="address";
    String S_ADDRESS="shipping_address";
    String COUNTRY="country";
    String CITY="city";
    String STATE="state";
    String PINCODE="pincode";
    String LandMark="landmark";
    String USER_IMAGE="user_image";
    String Deliver_Name="delivered_pname";
    String USER_TYPE="user_type";
    String USER_STATUS="status";


    String ENCODEDIMAGE ="encodedImage" ;
}
