package com.mrlonewolfer.onlinecakeshopping.Model;

public interface CategoryConst {
    String CID="cid";
    String CAT_NAME="category_name";
    String CAT_IMAGE="category_image";
    String ENCODEDIMAGE ="encodedImage" ;

    String SELECT_CATEGORY_TOAST="Select Product Category";
    String SELECT_ProductQTY_TOAST="Select Cake Size";
}
