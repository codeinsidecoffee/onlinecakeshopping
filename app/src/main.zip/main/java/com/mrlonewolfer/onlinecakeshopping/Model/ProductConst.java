package com.mrlonewolfer.onlinecakeshopping.Model;

public interface ProductConst {

    String PRODUCT_ID="product_id";
    String PRODUCT_TITLE="product_title";
    String PRODUCT_IMAGE="product_image";
    String PRODUCT_DESC="product_description";
    String PRODUCT_TYPE="product_type_name";
    String ENCODEDIMAGE ="encodedImage" ;
    String Cat_ID="cat_id";
    String PRODUCT_QTY_ID="product_qty_id";
    String PRODUCT_RATE_ID="product_rate_id";
    String PRODUCT_STATUS="product_status";
    String PRODUCT_RATE="product_rate";
    String PRODUCT_QTY_TYPE="product_qty_type";


}
