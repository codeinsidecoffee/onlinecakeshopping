package com.mrlonewolfer.onlinecakeshopping.Model;

public interface DBConst {
//    String BASE_URL="http://10.0.2.2/cakeshop/api/";
String BASE_URL="http://gujjujob.com.md-in-28.webhostbox.net/moreapps/cakeshop/api/";
//    String IMAGE_URL="http://10.0.2.2/cakeshop/";
    String IMAGE_URL="http://gujjujob.com.md-in-28.webhostbox.net/moreapps/cakeshop/";

    String USER_PHP_FILENAME="userinfo.php";
    String CATEGORY_PHP_FILENAME="categoryinfo.php";
    String PRODUCT_PHP_FILENAME="productinfo.php";
    String ADMINMASTER_PHP_FILENAME="adminmaster.php";
    String ORDER_PHP_FILENAME="orderinfo.php";
    String USER_URL=BASE_URL+USER_PHP_FILENAME;
    String CATEGORY_URL=BASE_URL+CATEGORY_PHP_FILENAME;


    String Flag="flag";
    String CASE_1="1";
    String CASE_2="2";
    String CASE_3="3";
    String CASE_4="4";
    String CASE_5="5";
    String CASE_6="6";
    String CASE_7="7";
    String CASE_8="8";
    String CASE_9="9";
    String CASE_10="10";
    String CASE_11="11";
    String CASE_12="12";
    String CASE_13="13";
    String CASE_14="14";
    String CASE_15="15";
    String CASE_16="16";
    String CASE_17="17";
    String CASE_18="18";
    String CASE_19="19";
    String CASE_20="20";
    String CASE_21 ="21";



    String CANCELED="Canceled";
    String INPROCESS="In Process";
    String PENDING="Pending";
    String COMPLETED="Completed";
    String successFullUserLogin="1 - login Successfull";
    String successFulladminLogin="0 - login Successfull";
    String unSuccessFullLogin="login unSuccessfull";

    String validUser="Valid User";
    String inValidUser="User Not Found";

    String successFullReset="Password successfully Change";

    public String FILE_NAME="Registration_Data";
    public String Successfull_INSERT="New record Inserted successfully";

    String PREF_STATUS ="LoggedIn" ;

    String Status_True="True";
    String Status_False="False";



}
